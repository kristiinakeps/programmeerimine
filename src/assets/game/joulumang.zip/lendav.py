import pygame
import random

class Lendav(pygame.sprite.Sprite):
    
    def __init__(self, akna_laius, akna_kõrgus, pilt):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(pilt)
        self.rect = self.image.get_rect()
        self.akna_laius = akna_laius
        self.akna_kõrgus = akna_kõrgus
        self.määra_asukoht()
    
    
    def määra_asukoht(self):
        self.rect.x = random.randint(0, self.akna_laius)
        self.rect.y = random.randint(-150, -50)
        self.kiirusy = random.randint(1, 7)
        self.kiirusx = random.randint(-3, 3)
        
    def update(self):
        self.rect.x += self.kiirusx
        self.rect.y += self.kiirusy
        if self.rect.top > self.akna_kõrgus or self.rect.right < 0 or self.rect.left > self.akna_laius:
            self.määra_asukoht()
        
