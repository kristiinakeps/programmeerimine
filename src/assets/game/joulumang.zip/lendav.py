import pygame
import random

class Lendav(pygame.sprite.Sprite):
    
    def __init__(self, akna_laius, akna_kõrgus, pilt):
        super().__init__()
        self.image = pygame.image.load(pilt)
        self.rect = self.image.get_rect()
        self.akna_laius = akna_laius
        self.akna_kõrgus = akna_kõrgus
        self.määra_asukoht()
    
    
    def määra_asukoht(self):
        self.rect.x = random.randint(0, self.akna_laius)
        self.rect.y = random.randint(-75, -25)
        self.kiirusy = 1
        self.kiirusx = random.randint(-1, 1)
        
    def update(self):
        self.rect.x += self.kiirusx
        self.rect.y += self.kiirusy
        if self.rect.top > self.akna_kõrgus or self.rect.right < 0 or self.rect.left > self.akna_laius:
            self.määra_asukoht()
        
