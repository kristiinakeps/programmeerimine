import pygame
import päkapikk
import lumepall
import kingitus

def joonista_elud(aken, palju_täidetud):
    riba_laius = 250
    riba_kõrgus = 20
    x = 15
    y = 15
    täidise_laius = palju_täidetud * riba_laius
    piirjoon = pygame.Rect(x, y, riba_laius, riba_kõrgus)
    täidis = pygame.Rect(x, y, täidise_laius, riba_kõrgus)
    pygame.draw.rect(aken, (0, 255, 0), täidis)
    pygame.draw.rect(aken, (255, 255, 255), piirjoon, 2)
    
def mäng(laius, kõrgus, aken, taustapilt):
    # font
    font = pygame.font.SysFont('Cooper Black', 40)
    
    # heli
    kokkupõrke_heli = pygame.mixer.Sound("vuhin.mp3")
    
    # peategelane
    tegelane_päkapikk = päkapikk.Päkapikk(laius // 2, kõrgus - 30, laius, 10)
    peategelane = pygame.sprite.Group()
    peategelane.add(tegelane_päkapikk)

    # lumepallid ja kingitused
    lumepallid = pygame.sprite.Group()
    kingitused = pygame.sprite.Group()
    for i in range(8):
        lumepallid.add(lumepall.Lumepall(laius, kõrgus))
        kingitused.add(kingitus.Kingitus(laius, kõrgus))

    algusaeg = pygame.time.get_ticks()  # mängu algusaeg

    # mängu tsükkel
    while True:    
        #kontrollime akna sulgemist
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None
        
        # uuendame sprite'ide grupid
        peategelane.update()
        lumepallid.update()
        kingitused.update()
        
        # jälgime kokkupõrkeid
        kokkupuutuvad_lumepallid = pygame.sprite.spritecollide(tegelane_päkapikk, lumepallid, False)
        for pall in kokkupuutuvad_lumepallid:
            pall.määra_asukoht()
            tegelane_päkapikk.vähenda_elusid()
            kokkupõrke_heli.play()
                
        kokkupuutuvad_kingitused = pygame.sprite.spritecollide(tegelane_päkapikk, kingitused, False)
        for kink in kokkupuutuvad_kingitused:
            kink.määra_asukoht()
            tegelane_päkapikk.suurenda_elusid()
            kokkupõrke_heli.play()
            
        # arvutame aja ja vajadusel lisame lumepalle ja kingitusi
        aeg = round((pygame.time.get_ticks() - algusaeg) / 1000, 1) # aeg sekundites
        if aeg % 5 == 0 and len(lumepallid) < 8 + aeg // 5:
            lumepallid.add(lumepall.Lumepall(laius, kõrgus))
        if aeg % 10 == 0 and len(kingitused) < 8 + aeg // 10:
            kingitused.add(kingitus.Kingitus(laius, kõrgus))
            
        if tegelane_päkapikk.elud == 0:
            return aeg

        # joonistame tausta
        aken.blit(taustapilt, (0, 0))
            
        peategelane.draw(aken)
        lumepallid.draw(aken)
        kingitused.draw(aken)
        
        # elud ja aeg
        joonista_elud(aken, tegelane_päkapikk.elud / tegelane_päkapikk.täiselud)
        aken.blit(font.render(str(aeg), True, (255, 255, 255)), (300, 10))
        
        # uuendame kasutaja jaoks vaadet
        pygame.display.flip()
        
def lõpuaken(aken, taustapilt, tulemus):
    
    # varasem rekord
    try:
        fail = open("rekord.txt")
        rekord = float(fail.read())
        fail.close()
    except:
        rekord = 0.0
        
    if tulemus > rekord:
        fail = open("rekord.txt", "w")
        fail.write(str(tulemus))
        fail.close()
    
    # fondid
    suur_font = pygame.font.SysFont('Cooper Black', 120)
    väike_font = pygame.font.SysFont('Cooper Black', 80)
    
    punane = (195, 20, 20)
    roheline = (50, 150, 0)
    tumeroheline = (30, 90, 0)
    
    mäng_läbi = suur_font.render("MÄNG LÄBI", True, punane)
    saadud_tulemus = väike_font.render("Tulemus: " + str(tulemus), True, punane)
    varasem_rekord = väike_font.render("Varasem rekord: " + str(rekord), True, punane)
    
    # uuesti mängimise tekst, peale liikudes muudab värvi
    mängi_uuesti_asukoht = (360, 640)
    mängi_uuesti_roheline = väike_font.render("Mängi uuesti", True, roheline)
    mängi_uuesti_tumeroheline = väike_font.render("Mängi uuesti", True, tumeroheline)
    
    # vajalik, et kontrollida, kas hiir on "Mängi uuesti" peal
    mängi_uuesti_rect = mängi_uuesti_roheline.get_rect()
    mängi_uuesti_rect.x = mängi_uuesti_asukoht[0]
    mängi_uuesti_rect.y = mängi_uuesti_asukoht[1]
    
    while True:
        hiire_asukoht = pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and mängi_uuesti_rect.collidepoint(hiire_asukoht):
                return True
        aken.blit(taustapilt, (0, 0))
        aken.blit(mäng_läbi, (260, 200))
        aken.blit(saadud_tulemus, (340, 440))
        aken.blit(varasem_rekord, (200, 540))

        if mängi_uuesti_rect.collidepoint(hiire_asukoht):
            aken.blit(mängi_uuesti_tumeroheline, mängi_uuesti_asukoht)
        else:
            aken.blit(mängi_uuesti_roheline, mängi_uuesti_asukoht)
        pygame.display.flip()

pygame.init()

# akna loomine
laius = 1262 # laius ja pikkus on pikslites
kõrgus = 845
aken = pygame.display.set_mode((laius, kõrgus))
pygame.display.set_caption("Jõulumäng")

# taustapilt
taustapilt = pygame.image.load("taust.png")

tulemus = mäng(laius, kõrgus, aken, taustapilt)
while tulemus != None:
    uus_mäng = lõpuaken(aken, taustapilt, tulemus)
    if uus_mäng:
        tulemus = mäng(laius, kõrgus, aken, taustapilt)
    else:
        tulemus = None

pygame.quit()