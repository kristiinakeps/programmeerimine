import random
import lendav

class Lumepall(lendav.Lendav):
    
    def __init__(self, akna_laius, akna_kõrgus):
        võimalikud_pildid = ["lumepall_1.png", "lumepall_2.png", "lumepall_3.png", "lumepall_4.png", "lumepall_5.png"]
        pilt = random.choice(võimalikud_pildid)
        super().__init__(akna_laius, akna_kõrgus, pilt)
        