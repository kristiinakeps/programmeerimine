import random
import lendav

class Kingitus(lendav.Lendav):
    
    def __init__(self, akna_laius, akna_kõrgus):
        võimalikud_pildid = ["kingitus_1.png", "kingitus_2.png", "kingitus_3.png", "kingitus_4.png", "kingitus_5.png"]
        pilt = random.choice(võimalikud_pildid)
        super().__init__(akna_laius, akna_kõrgus, pilt)
