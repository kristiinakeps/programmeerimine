import pygame

class Päkapikk(pygame.sprite.Sprite):
    def __init__(self, x, y, akna_laius, täiselud):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("päkapikk.png")
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.bottom = y
        self.akna_laius = akna_laius
        self.täiselud = täiselud
        self.elud = täiselud

    def update(self):
        kiirus = 5
        klahvid = pygame.key.get_pressed()
        if klahvid[pygame.K_LEFT]:
            self.rect.centerx -= kiirus
        if klahvid[pygame.K_RIGHT]:
            self.rect.centerx += kiirus
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > self.akna_laius:
            self.rect.right = self.akna_laius
            
    def vähenda_elusid(self):
        self.elud -= 1
        if self.elud < 0:
            self.elud = 0
            
    def suurenda_elusid(self):
        self.elud += 1
        if self.elud > self.täiselud:
            self.elud = self.täiselud