from flask import Flask, render_template, request, url_for, redirect

rakendus = Flask(__name__)

ootel_kodutööd = []

@rakendus.route("/", methods=('GET', 'POST'))
def avaleht():
    if request.method == "POST":
        kodutöö = request.form["kodutöö"]
        ootel_kodutööd.remove(kodutöö)
    return render_template("avaleht.html", kodutööd = ootel_kodutööd)

@rakendus.route("/lisamine", methods=('GET', 'POST'))
def lisamine():
    if request.method == "POST":
        kodutöö = request.form["kodutöö"]
        ootel_kodutööd.append(kodutöö)
        return redirect(url_for("avaleht"))
    return render_template("lisamine.html")
